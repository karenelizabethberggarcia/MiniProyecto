package cartas;

public class Monstruo extends Carta {

    private int atkBase;
    private int atk;
    private int def;
    private int nivel;
    private boolean posicion;// True es ataque y Falso es defensa
    private boolean yaAtaco;

    public Monstruo (String nombre, int atk, int def, int nivel, String descripcion ){

        super(nombre, descripcion); //se le pasa el nombre y descripción a la clase padre

        this.atkBase = atk; //el valor original que no cambia
        this.atk = atk; //valor actual que cambia con los efectos
        this.def = def;
        this.nivel = nivel; //se guardan los valores recibidos dentro del objeto
        this.posicion = true;
        this.yaAtaco = false;

    }


    public boolean getPosicion(){

        return posicion;
    }


    public int getAtk(){

        return atk;

    }

    public void setAtk (int atk){

        this.atk = atk;
    }
    
    public int getDef(){

        return def;

    }

    public void setDef(int def){

        this.def = def;
    }



    public int getNivel(){

        return nivel;

    } //para poder obtener sus valores que vienen de la clase privada



    public void resetAtk(){

        this.atk = atkBase;
    }


    public int atacar( Monstruo enemigo){



        if (enemigo.getPosicion()){

            int enfrentamiento = atk - enemigo.getAtk();
            return enfrentamiento;
        }else{

            int enfrentamiento = atk - enemigo.getDef();
            if (enfrentamiento >= 0){
                return 0; //aunque el ataque sea superior no roba puntos de vida
            }else{
                return enfrentamiento;
            }

        }
    

    }

    public void cambiarPosicion(){

        posicion = !posicion;

    }

    public boolean yaAtaco(){

    return yaAtaco;

    }

    public void marcarAtaque(){

    this.yaAtaco = true; 

    }

    public void reiniciarAtaque(){

    this.yaAtaco = false;
    }



}
