package vista;

import cartas.Carta;
import cartas.CartaMagica;
import cartas.CartaTrampa;
import cartas.Monstruo;
import jugadores.Jugador;
import juego.Mazo;
import juego.Juego;

import javax.swing.*;

public class App {

    private static Vista vista;

    public static void main(String[] args) {
        // Menu de inicio
        String nombre1 = "";
        String nombre2 = "";
        
        // Preguntar nombres
        while (nombre1 == null || nombre1.trim().isEmpty()) {
            nombre1 = JOptionPane.showInputDialog(null, 
                "Ingresa el nombre del Duelista 1:", 
                "Registro de Duelistas", 
                JOptionPane.QUESTION_MESSAGE);
            if (nombre1 == null) return; // Cancelar
            if (nombre1.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "El nombre no puede estar vacio", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        while (nombre2 == null || nombre2.trim().isEmpty()) {
            nombre2 = JOptionPane.showInputDialog(null, 
                "Ingresa el nombre del Duelista 2:", 
                "Registro de Duelistas", 
                JOptionPane.QUESTION_MESSAGE);
            if (nombre2 == null) return; // Cancelar
            if (nombre2.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "El nombre no puede estar vacio", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        // Preguntar modo de juego
        String[] opciones = {"Interfaz Grafica (GUI)", "Consola"};
        int modoSeleccionado = JOptionPane.showOptionDialog(null, 
            "Selecciona el modo de juego:", 
            "Modo de Juego",
            JOptionPane.DEFAULT_OPTION, 
            JOptionPane.QUESTION_MESSAGE, 
            null, 
            opciones, 
            opciones[0]);
        
        if (modoSeleccionado == 0) {
            // GUI
            vista = new InterfazGrafica();
        } else {
            // Modo Consola
            vista = new Consola();
        }

        vista.mostrarBienvenida();

        vista.mostrarMensaje(" Duelista 1: " + nombre1);
        vista.mostrarMensaje(" Duelista 2: " + nombre2);
        vista.mostrarMensaje(" ¡" + nombre1 + " VS " + nombre2 + "! ");
        vista.mostrarMensaje(" Que comience el duelo ");

        vista.pausar();

        Jugador j1 = new Jugador(nombre1);
        Jugador j2 = new Jugador(nombre2);

        Mazo.repartir(j1, j2);

        Juego juego = new Juego(j1, j2);

        vista.mostrarEstadoCompleto(juego);
        vista.pausar();

        int turnosJugados = 0;

        while (!juego.hayGanador()) {

            Jugador actual = juego.getJugadorActual();
            Jugador enemigo = juego.getJugadorEnemigo();

            vista.mostrarTurno(turnosJugados + 1, actual.getNombre());

            // Fase de robo
            vista.mostrarFase("Fase Robo");
            boolean puedeContinuar = actual.robarCarta();
            if (!puedeContinuar) {
                break; // Mazo vacio, derrota
            }

            vista.mostrarEstadoCompleto(juego);
            vista.pausar();

            // Fase principal
            vista.mostrarFase("Fase principal");
            ejecutarFasePrincipal(juego, actual);

            // Fase de batalla
            vista.mostrarFase("Fase batalla");
            ejecutarFaseBatalla(juego, actual, enemigo);

            // Fase final
            juego.faseFinal();

            vista.mostrarEstadoCompleto(juego);
            turnosJugados++;

            if (juego.hayGanador()) break;

            vista.pausar();
        }

        vista.mostrarPantallaFinal(juego, j1, j2, turnosJugados);
    }

    private static void ejecutarFasePrincipal(Juego juego, Jugador actual) {
        if (actual.getMano().isEmpty()) {
            vista.mostrarMensaje(" (Mano vacia - no puedes jugar cartas) ");
            return;
        }

        vista.mostrarManoConTipo(actual);

        vista.mostrarMensaje(" Que deseas hacer? ");
        vista.mostrarOpciones(new String[]{"Jugar una carta", "Pasar (no jugar carta este turno)"});

        int opcion = vista.leerEntero(1, 2);

        if (opcion == 2) {
            vista.mostrarMensaje(" " + actual.getNombre() + " decide no jugar carta ");
            return;
        }

        vista.mostrarMensaje("Que carta quieres jugar? ");
        vista.mostrarMensaje("  [0] Cancelar");

        int indice = vista.leerEntero(0, actual.getMano().size());

        if (indice == 0) {
            vista.mostrarMensaje(" Accion cancelada ");
            return;
        }

        Carta cartaElegida = actual.getMano().get(indice - 1);

        if (cartaElegida instanceof Monstruo) {
            Monstruo monstruo = (Monstruo) cartaElegida;
            
            // Verificar si requiere sacrificio (nivel > 4)
            if (monstruo.getNivel() > 4) {
                if (!actual.tieneMonstruosParaSacrificio()) {
                    vista.mostrarMensaje(" ❌ No tienes monstruos en campo para sacrificar!");
                    vista.mostrarMensaje(" Este monstruo requiere sacrificio (Nivel " + monstruo.getNivel() + ")");
                    return;
                }
                vista.mostrarMensaje(" ⚠️ Este monstruo requiere sacrificio (Nivel " + monstruo.getNivel() + ")");
                vista.mostrarMensaje(" Selecciona un monstruo de tu campo para sacrificar:");
                int indiceSacrificio = vista.seleccionarSacrificio(actual, "Elige el monstruo a sacrificar:");
                
                if (indiceSacrificio == 0) {
                    vista.mostrarMensaje(" Invocacion cancelada");
                    return;
                }
                
                Monstruo sacrificio = actual.getCampo().get(indiceSacrificio - 1);
                actual.jugarMonstruo(monstruo, sacrificio);
            } else {
                actual.jugarMonstruo(monstruo);
            }
            vista.mostrarCartaJugada(actual.getNombre(), cartaElegida.getNombre());
        } else if (cartaElegida instanceof CartaMagica) {
            CartaMagica magica = (CartaMagica) cartaElegida;
            actual.jugarMagia(magica);
            vista.mostrarCartaJugada(actual.getNombre(), cartaElegida.getNombre());
        } else if (cartaElegida instanceof CartaTrampa) {
            CartaTrampa trampa = (CartaTrampa) cartaElegida;
            actual.jugarTrampa(trampa);
            vista.mostrarCartaJugada(actual.getNombre(), cartaElegida.getNombre());
        }
    }

    private static void ejecutarFaseBatalla(Juego juego, Jugador actual, Jugador enemigo) {
        if (juego.esPrimerTurno()) {
            vista.mostrarMensaje(" Primer turno: no se puede atacar ");
            return;
        }

        if (actual.getCampo().isEmpty()) {
            vista.mostrarMensaje(" No tienes monstruos en campo para atacar ");
            return;
        }

        vista.mostrarMensaje(" Deseas atacar este turno? ");
        vista.mostrarOpciones(new String[]{"Si, atacar", "No atacar (pasar)"});

        int opcion = vista.leerEntero(1, 2);

        if (opcion == 2) {
            vista.mostrarMensaje(" " + actual.getNombre() + " decide no atacar ");
            return;
        }

        int eleAtacante = vista.seleccionarMonstruoCampo(actual, "Elige el monstruo atacante:");
        if (eleAtacante == 0) {
            vista.mostrarMensaje(" Ataque cancelado.");
            return;
        }
        if (eleAtacante < 0 || eleAtacante > actual.getCampo().size()) {
            vista.mostrarMensaje(" Selección inválida de atacante. Ataque cancelado.");
            return;
        }

        Monstruo atacante = actual.getCampo().get(eleAtacante - 1);

        if (atacante.yaAtaco()) {
            vista.mostrarMensaje(" Ese monstruo ya ataco este turno ");
            return;
        }

        if (!enemigo.getCampo().isEmpty()) {
            int eleDefensor = vista.seleccionarMonstruoCampo(enemigo, "Elige el objetivo del ataque:");
            if (eleDefensor == 0) {
                vista.mostrarMensaje(" Ataque cancelado.");
                return;
            }
            if (eleDefensor < 0 || eleDefensor > enemigo.getCampo().size()) {
                vista.mostrarMensaje(" Selección inválida de objetivo. Ataque cancelado.");
                return;
            }
            if (eleDefensor > 1) {
                java.util.Collections.swap(enemigo.getCampo(), 0, eleDefensor - 1);
            }
        } else {
            vista.mostrarMensaje(" ¡Ataque directo al jugador enemigo!");
}

        // ACTIVAR TRAMPAS DEL OPONENTE ANTES DEL ATAQUE
        if (enemigo.tieneTrampas()) {
            vista.mostrarMensaje(" El oponente tiene trampas activadas!");
            // Activar trampas pasando el monstruo atacante para que aplicuen efectos correctamente
            enemigo.activarTrampas(actual, actual.getCampo().get(eleAtacante - 1));
        }

// CALCULAR Y APLICAR EL DAÑO
        actual.atacarJugador(enemigo);
    }
}